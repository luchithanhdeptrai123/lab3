﻿function Homnay() {
    var d = new Date();
    alert("Hôm nay là ngày " + d.getDate() + " tháng " + d.getMonth() + " năm " +
        d.getFullYear()
    );
}